
(function(){
if (window.__UA_A) { return; } window.__UA_A = 1;
var LS=window.localStorage, SS=window.sessionStorage;
function rnd(){ return Math.random().toString(36).slice(2)+Date.now().toString(36); }
function get(k,st){ try{ return st.getItem(k); }catch(e){ return null; } }
function set(k,v,st){ try{ st.setItem(k,v); }catch(e){} }
var vid=get('ua_vid',LS); if(!vid){ vid=rnd(); set('ua_vid',vid,LS); }
var now=Date.now();
var last=parseInt(get('ua_last',LS)||'0',10);
var sid=get('ua_sid',LS);
var novaya=false;
if(!sid || !last || (now-last)>1800000){ sid=rnd(); set('ua_sid',sid,LS); novaya=true; }
set('ua_last',String(now),LS);
var par=new URLSearchParams(location.search);
function utm(n){ return (par.get(n)||'').slice(0,100); }
var us=utm('utm_source'), um=utm('utm_medium'), uc=utm('utm_campaign'), uk=utm('utm_content');
function istochnik(){
  if(us){ var m=us.toLowerCase();
    if(m.indexOf('tik')>=0) return 'TikTok';
    if(m.indexOf('insta')>=0||m==='ig') return 'Instagram';
    if(m.indexOf('face')>=0||m==='fb') return 'Facebook';
    if(m.indexOf('goog')>=0) return 'Google';
    if(m.indexOf('tele')>=0||m==='tg') return 'Telegram';
    if(m.indexOf('what')>=0) return 'WhatsApp';
    if(m.indexOf('ria')>=0) return 'AUTO.RIA';
    return us; }
  var r=document.referrer||'';
  if(!r) return 'Прямой / неизвестный';
  try{ var h=new URL(r).hostname.replace('www.',''); }catch(e){ return 'Другой сайт'; }
  if(h.indexOf(location.hostname)>=0) return '';
  if(h.indexOf('tiktok')>=0) return 'TikTok';
  if(h.indexOf('instagram')>=0) return 'Instagram';
  if(h.indexOf('facebook')>=0||h.indexOf('fb.')>=0) return 'Facebook';
  if(h.indexOf('google')>=0) return 'Google';
  if(h.indexOf('t.me')>=0||h.indexOf('telegram')>=0) return 'Telegram';
  if(h.indexOf('whatsapp')>=0) return 'WhatsApp';
  if(h.indexOf('auto.ria')>=0) return 'AUTO.RIA';
  if(h.indexOf('bing')>=0||h.indexOf('yandex')>=0||h.indexOf('duck')>=0) return 'Поиск';
  return h;
}
var ist=istochnik();
if(ist===''){ ist=get('ua_ist',LS)||'Прямой / неизвестный'; } else { set('ua_ist',ist,LS); }
if(novaya){ set('ua_ist',ist,LS); }
var poslednie={};
function shlyom(t,z){
  var klyuch=t+'|'+(z||'')+'|'+location.pathname;
  var tt=Date.now();
  if(poslednie[klyuch] && (tt-poslednie[klyuch])<1200){ return; }
  poslednie[klyuch]=tt;
  var d={t:t,v:vid,s:sid,e:rnd()+rnd(),p:location.pathname+location.search,z:z||'',
         i:ist,us:us,um:um,uc:uc,uk:uk};
  var telo=JSON.stringify(d);
  try{
    if(navigator.sendBeacon){ navigator.sendBeacon('/ua/a/e', new Blob([telo],{type:'text/plain'})); return; }
  }catch(e){}
  try{ fetch('/ua/a/e',{method:'POST',body:telo,keepalive:true}); }catch(e){}
}
if(novaya){ shlyom('start',''); }
var p=location.pathname.toLowerCase();
if(/ua-\d+.*-diag/.test(p)){ shlyom('diag',''); }
else if(/ua-\d+/.test(p)){ shlyom('card',''); }
else { shlyom('page',''); }
document.addEventListener('click', function(ev){
  var a=ev.target; var i=0;
  while(a && a.tagName!=='A' && i<6){ a=a.parentNode; i++; }
  var h=(a && a.getAttribute && a.getAttribute('href')) || '';
  var txt=((a && a.textContent) || (ev.target && ev.target.textContent) || '').trim().slice(0,60);
  var hl=h.toLowerCase();
  if(hl.indexOf('wa.me')>=0 || hl.indexOf('whatsapp')>=0){ shlyom('whatsapp',txt); return; }
  if(hl.indexOf('t.me')>=0 || hl.indexOf('tg://')>=0){ shlyom('telegram',txt); return; }
  if(hl.indexOf('tel:')===0){ shlyom('phone',txt); return; }
  if(hl.indexOf('-diag')>=0){ shlyom('diag',txt); return; }
  if(/ua-\d+\.html/.test(hl)){ shlyom('obyavlenie',txt); return; }
  if(hl.indexOf('podbor')>=0){ shlyom('zakaz',txt); return; }
  if(hl.indexOf('katalog')>=0 && hl.indexOf('stage')>=0){ shlyom('etap',txt); return; }
  var t2=txt.toLowerCase();
  if(t2.indexOf('позвонить')>=0){ shlyom('phone',txt); return; }
  if(t2.indexOf('подел')>=0 || t2.indexOf('share')>=0){ shlyom('share',txt); return; }
  if(t2.indexOf('купить')>=0 || t2.indexOf('заброн')>=0 || t2.indexOf('вопрос')>=0 || t2.indexOf('заявк')>=0){ shlyom('cta',txt); return; }
}, true);
document.addEventListener('play', function(ev){
  if(ev.target && ev.target.tagName==='VIDEO'){ shlyom('video',''); }
}, true);
})();
