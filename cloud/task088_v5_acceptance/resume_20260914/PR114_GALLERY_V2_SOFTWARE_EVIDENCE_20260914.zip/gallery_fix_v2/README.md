# Gallery builder v2: frozen candidate verification

Actual unmodified gate: **351/351 PASS**. All captured-source suites:
**95/95 PASS**. Combined price software checks: **446/446 PASS**.
Required maintenance unittest discovery: **183/183 PASS**.
All failures, errors and skips are zero; no expected failures or unexpected
successes were accepted. Counts are the observed results and were not forced.

Builder SHA256: `ce6fb512f2b2c5dadb81c6412b1da28a43b8ba0d8b9d325f93c03833d9368cc9`.
Source manifest SHA256: `0dae6071812640061367ef54dedb52a4b6a8e155449d526202f2496f52b55f38`.

The full source inventory and all 65 captured private files were unchanged
before/after this run. The capture manifest is
`80caa235053ad81550415b162060f4d77661967fc8ed97fb4fef0d5aff87db7b`.
No private source contents, CRM rows or application credentials are included.
The private logs contain only standard successful unittest output.

`PUBLIC_GATE.json` and its raw logs preserve the actual public gate.
`raw/private_*.json` and associated logs preserve all eight captured-source files.
`MAINTENANCE.json` and its raw logs preserve the required discovery command.
`SOURCE_BINDING_BEFORE.json` and `FINAL_CURRENT_CANDIDATE_RESULTS.json` provide
exact source hashes, commands, timings, counts and unchanged-input checks.
`run_current_candidate.py` is the coordinator used for these executions.

This is fresh offline verification of builder v2, including the additional
literal diagnostic gallery asset path recognition. It is not a live browser,
server, CRM, publication or Stage 4 acceptance result. Earlier v1 and historical
443 evidence remain unchanged in their own folders and archives.

No UI, server, Git refs or production state were changed by this workstream.
Python runtime: `3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]`.
