#!/usr/bin/env python3
"""Offline actual current gate, captured-source tests and maintenance discovery."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent
CAPTURE = Path('/workspace/scratch/256f936ac1c5/private_v5_routing')
BUILDER_SHA = 'ce6fb512f2b2c5dadb81c6412b1da28a43b8ba0d8b9d325f93c03833d9368cc9'
COUNTERS = ('tests_run','failures','errors','skipped','expected_failures','unexpected_successes')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name,value):
    with (OUT/name).open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')

def capture_hashes():
    manifest=json.loads((CAPTURE/'capture_manifest.json').read_text())
    actual={}
    for name,expected in manifest['sha256'].items():
        path=CAPTURE/name
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(CAPTURE):
            raise ValueError('CAPTURE_PATH')
        actual[name]=sha(path.read_bytes())
        if actual[name]!=expected:
            raise ValueError('CAPTURE_HASH_MISMATCH:'+name)
    return actual

def execute(stem,command,private=False):
    with tempfile.TemporaryDirectory(prefix='pr114-current-offline-') as temporary:
        env={k:os.environ[k] for k in ('PATH','SYSTEMROOT') if k in os.environ}
        env.update(TMPDIR=temporary,TMP=temporary,TEMP=temporary)
        if private:
            env.update(UA088_LIVE_SOURCE_DIR=str(CAPTURE),
                TASK088_CARS_UI_SOURCE=str(CAPTURE/'cars_ui.py'),
                TASK088_PUBLISH_GUARD_SOURCE=str(CAPTURE/'publish_transaction_guard.py'))
        started=now()
        proc=subprocess.run(command,cwd=ROOT if stem=='maintenance' else temporary,
                            env=env,capture_output=True,timeout=300)
    if not private or proc.returncode==0:
        (OUT/'raw'/(stem+'.stdout.log')).write_bytes(proc.stdout)
        (OUT/'raw'/(stem+'.stderr.log')).write_bytes(proc.stderr)
    result={'command':command,'started_at':started,'finished_at':now(),'exit_code':proc.returncode,
            'stdout_sha256':sha(proc.stdout),'stderr_sha256':sha(proc.stderr),
            'logs_preserved':not private or proc.returncode==0}
    return result,proc

def main():
    spec=importlib.util.spec_from_file_location('current_price_gate',ROOT/'cloud/ua_ge_price_protection/gate.py')
    gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
    before=gate.source_inventory(ROOT)
    if before['cloud/task088_v5_preview/build_preview.py']!=BUILDER_SHA:
        raise ValueError('FROZEN_BUILDER_DRIFT')
    capture_before=capture_hashes()
    report={'kind':'CURRENT_GALLERY_V2_FIXED_CANDIDATE_OFFLINE_VERIFICATION','started_at':now(),
        'source_manifest_sha256':gate.digest(gate.encoded(before)),
        'source_files_sha256':before,'builder_sha256':BUILDER_SHA,
        'live_preview_tested':False,'production_written':False,'real_crm_tested':False}
    save('SOURCE_BINDING_BEFORE.json',report)
    public,proc=execute('public_gate',[sys.executable,'-I','-B',str(ROOT/'cloud/ua_ge_price_protection/gate.py'),
                                     '--output',str(OUT/'PUBLIC_GATE.json')])
    public['result']=json.loads((OUT/'PUBLIC_GATE.json').read_text())
    report['public']=public
    print(json.dumps({'public_status':public['result']['software_status'],
                      'public_tests':sum(s['tests_run'] for s in public['result']['suites'])}),flush=True)
    private_files=[
        ('cloud/task088_stage3_renderer','test_private_source.py'),
        ('cloud/task088_stage3_renderer','test_captured_pages.py'),
        ('cloud/task088_stage3_renderer','test_private_catalog_guard.py'),
        ('cloud/task088_stage3_renderer','test_private_master_chain.py'),
        ('cloud/task088_stage3_renderer','test_private_stage_catalog_sync.py'),
        ('cloud/task088_price_sync','test_cars_ui_hook.py'),
        ('cloud/task088_price_sync','test_guard_fence.py'),
        ('cloud/task088_v5_preview','test_private_preview_capture.py'),
    ]
    private=[]
    for index,(folder,name) in enumerate(private_files,1):
        stem=f'private_{index:02d}_{name[:-3]}'
        result_path=OUT/'raw'/(stem+'.json')
        result,_=execute(stem,[sys.executable,'-I','-B',str(ROOT/'cloud/ua_ge_price_protection/run_suite.py'),
            '--directory',str(ROOT/folder),'--result',str(result_path),name],private=True)
        result.update(directory=folder,file=name,result=json.loads(result_path.read_text()))
        private.append(result)
        print(json.dumps({'private_file':name,'result':result['result']}),flush=True)
    report['private']=private
    maintenance,proc=execute('maintenance',[sys.executable,'-I','-B','-m','unittest','discover',
        '-s','automation/packages/task107_r2','-p','test_*.py','-v'])
    stderr=proc.stderr.decode()
    count=re.search(r'Ran (\d+) tests? in ([\d.]+)s',stderr)
    maintenance['result']={'tests_run':int(count.group(1)) if count else None,
        'failures':len(re.findall(r'^FAIL:',stderr,re.M)),'errors':len(re.findall(r'^ERROR:',stderr,re.M)),
        'skipped':len(re.findall(r'\.\.\. skipped ',stderr)),'status':'PASS' if proc.returncode==0 and re.search(r'^OK\s*$',stderr,re.M) else 'FAIL'}
    report['maintenance']=maintenance
    save('MAINTENANCE.json',maintenance)
    report['private_totals']={k:sum(x['result'][k] for x in private) for k in COUNTERS}
    report['public_totals']={k:sum(s[k] for s in public['result']['suites']) for k in COUNTERS}
    report['combined_price_test_totals']={k:report['private_totals'][k]+report['public_totals'][k] for k in COUNTERS}
    report['sources_unchanged_after']=gate.source_inventory(ROOT)==before
    report['capture_unchanged_after']=capture_hashes()==capture_before
    report['capture_verified_files']=len(capture_before)
    report['capture_manifest_sha256']=sha((CAPTURE/'capture_manifest.json').read_bytes())
    report['finished_at']=now()
    report['status']='PASS' if (public['exit_code']==0 and public['result']['software_status']=='PASS'
        and all(x['exit_code']==0 for x in private) and maintenance['result']['status']=='PASS'
        and report['sources_unchanged_after'] and report['capture_unchanged_after']) else 'FAIL'
    save('FINAL_CURRENT_CANDIDATE_RESULTS.json',report)
    print(json.dumps({k:report[k] for k in ('status','public_totals','private_totals','combined_price_test_totals',
          'sources_unchanged_after','capture_unchanged_after','source_manifest_sha256')},indent=2))
    print(json.dumps({'maintenance':maintenance['result']}))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
