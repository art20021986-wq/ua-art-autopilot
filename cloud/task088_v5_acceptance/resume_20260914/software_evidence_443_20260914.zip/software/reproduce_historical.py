#!/usr/bin/env python3
"""Reproduce the recorded 443 offline checks; does not replace the current gate."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
CAPTURE = Path('/workspace/scratch/256f936ac1c5/private_v5_routing')
HISTORICAL = ROOT / 'cloud/ua_ge_price_protection/SOFTWARE_GATE_KYIV_VISIBILITY_V5.json'
RUNNER = ROOT / 'cloud/ua_ge_price_protection/run_suite.py'
COUNTERS = ('tests_run', 'failures', 'errors', 'skipped', 'expected_failures', 'unexpected_successes')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')

def capture_inventory():
    manifest_path = CAPTURE/'capture_manifest.json'
    manifest = json.loads(manifest_path.read_text())
    hashes = {}
    for name, expected in manifest['sha256'].items():
        path = CAPTURE/name
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(CAPTURE.resolve()):
            raise ValueError('CAPTURE_PATH_INVALID:' + name)
        actual = sha(path.read_bytes())
        if actual != expected:
            raise ValueError('CAPTURE_HASH_MISMATCH:' + name)
        hashes[name] = actual
    return {'manifest_sha256': sha(manifest_path.read_bytes()), 'files_sha256': hashes,
            'verified_files':len(hashes), 'recorded_published_count':manifest['published_count'],
            'recorded_missing_inputs':manifest.get('missing',[]),
            'scope':'EXISTING_CAPTURE_INTEGRITY_ONLY_NOT_CURRENT_LIVE_STATE'}

def main():
    gate_path = ROOT/'cloud/ua_ge_price_protection/gate.py'
    spec = importlib.util.spec_from_file_location('resume_gate_inventory', gate_path)
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    before = gate.source_inventory(ROOT)
    historical = json.loads(HISTORICAL.read_text())
    capture_before = capture_inventory()
    save('capture_integrity_before.json', capture_before)
    save('source_binding.json', {
        'recorded_at':now(), 'candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'source_files_sha256':before, 'source_manifest_sha256':gate.digest(gate.encoded(before)),
        'historical_report_sha256':sha(HISTORICAL.read_bytes()),
        'historical_source_manifest_sha256':historical['source_manifest_sha256'],
        'source_files_exactly_match_historical':before == historical['source_files_sha256'],
        'historical_manifest_mismatch_paths':sorted(k for k in set(before)|set(historical['source_files_sha256']) if before.get(k)!=historical['source_files_sha256'].get(k)),
        'selection_policy':'Historical explicit test files only; current gate discovery is assessed separately and never bypassed.'})
    cases = []
    for suite in historical['suites']:
        folder = gate.REQUIRED_TESTS[suite['suite']][0]
        for item in suite['files']:
            cases.append(('public',suite['suite'],folder,item['file'],item['tests_run']))
    private = [
        ('cloud/task088_stage3_renderer','test_private_source.py',11),
        ('cloud/task088_stage3_renderer','test_captured_pages.py',6),
        ('cloud/task088_stage3_renderer','test_private_catalog_guard.py',2),
        ('cloud/task088_stage3_renderer','test_private_master_chain.py',2),
        ('cloud/task088_stage3_renderer','test_private_stage_catalog_sync.py',7),
        ('cloud/task088_price_sync','test_cars_ui_hook.py',37),
        ('cloud/task088_price_sync','test_guard_fence.py',24),
        ('cloud/task088_v5_preview','test_private_preview_capture.py',6),
    ]
    cases.extend(('private','captured_source',folder,name,count) for folder,name,count in private)
    report = {'kind':'REPRODUCED_HISTORICAL_SOFTWARE_AND_CAPTURE_TESTS', 'started_at':now(),
              'production_written':False,'live_preview_tested':False,'real_crm_cycle_tested':False,
              'current_gate_status':'ASSESSED_SEPARATELY_NOT_REPLACED_BY_THIS_REPORT',
              'source_manifest_sha256':gate.digest(gate.encoded(before)), 'suites':[]}
    for index,(visibility,suite,folder,name,expected) in enumerate(cases,1):
        stem = f'{index:02d}_{visibility}_{suite}_{name[:-3]}'
        result = OUT/'raw'/f'{stem}.json'
        with tempfile.TemporaryDirectory(prefix='pr114-historical-') as temporary:
            environment = {k:os.environ[k] for k in ('PATH','SYSTEMROOT') if k in os.environ}
            environment.update(TMPDIR=temporary,TMP=temporary,TEMP=temporary)
            if visibility == 'private':
                environment.update(UA088_LIVE_SOURCE_DIR=str(CAPTURE),
                    TASK088_CARS_UI_SOURCE=str(CAPTURE/'cars_ui.py'),
                    TASK088_PUBLISH_GUARD_SOURCE=str(CAPTURE/'publish_transaction_guard.py'))
            command=[sys.executable,'-I','-B',str(RUNNER),'--directory',str(ROOT/folder),'--result',str(result),name]
            started=now()
            proc=subprocess.run(command,cwd=temporary,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
        # Successful unittest logs contain counts and markers only. Private
        # failure detail stays transient unless reviewed for safe disclosure.
        if proc.returncode == 0 or visibility == 'public':
            (OUT/'raw'/f'{stem}.stdout.log').write_bytes(proc.stdout)
            (OUT/'raw'/f'{stem}.stderr.log').write_bytes(proc.stderr)
            log_status='RAW_PRESERVED'
        else:
            log_status='PRIVATE_FAILURE_DETAIL_WITHHELD_FROM_PUBLIC_EVIDENCE'
        counters=json.loads(result.read_text()) if result.exists() else None
        entry={'visibility':visibility,'suite':suite,'directory':folder,'file':name,
            'expected_historical_count':expected,'started_at':started,'finished_at':now(),
            'exit_code':proc.returncode,'result':counters,'logs':log_status,
            'stdout_sha256':sha(proc.stdout),'stderr_sha256':sha(proc.stderr)}
        report['suites'].append(entry)
        print(json.dumps({'file':name,'visibility':visibility,'exit_code':proc.returncode,'result':counters}),flush=True)
    report['totals']={v:{k:sum((x['result'] or {}).get(k,0) for x in report['suites'] if x['visibility']==v) for k in COUNTERS} for v in ('public','private')}
    report['totals']['combined']={k:sum(report['totals'][v][k] for v in ('public','private')) for k in COUNTERS}
    report['historical_test_counts_exact']=all(x['result'] and x['result']['tests_run']==x['expected_historical_count'] for x in report['suites'])
    report['sources_unchanged_after']=gate.source_inventory(ROOT)==before
    capture_after=capture_inventory()
    save('capture_integrity_after.json',capture_after)
    report['capture_unchanged_after']=capture_after==capture_before
    report['finished_at']=now()
    report['status']='PASS' if all(x['exit_code']==0 for x in report['suites']) and report['historical_test_counts_exact'] and report['sources_unchanged_after'] and report['capture_unchanged_after'] else 'FAIL'
    save('historical_443_results.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='suites'},sort_keys=True),flush=True)
    return 0 if report['status']=='PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
