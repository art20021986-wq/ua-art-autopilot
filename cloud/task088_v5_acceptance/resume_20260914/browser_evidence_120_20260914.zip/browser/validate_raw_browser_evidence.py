#!/usr/bin/env python3
"""Evaluate genuine saved CSS observations; never collect or fabricate evidence.

The source rows must be an independently captured private published-row file.
Only its digest is included in the report. This is a CSS observation matrix
verdict, not the complete Preview/production gate or an iOS/Safari verdict.
"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
LANGUAGES = {"RU": "ru", "UA": "uk", "GE": "ka"}
VIEWPORTS = ((390, 844), (1280, 900))
EPSILON = 1.0


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compact_key(key):
    path, language, width, height = key
    return f"{path}|{language}|{width}x{height}"


def key_of(observation):
    viewport = observation.get("requested_css_viewport", {})
    return (observation.get("path"), observation.get("requested_language"),
            viewport.get("width"), viewport.get("height"))


def normalized_text(value):
    return " ".join(str(value).split())


def numeric(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def usable_box(box, document_width):
    return (isinstance(box, dict) and all(numeric(box.get(key)) for key in ("x", "y", "width", "height"))
            and box["width"] > 0 and box["height"] > 0
            and box["x"] >= -EPSILON and box["x"] + box["width"] <= document_width + EPSILON)


def inside(inner, outer):
    return (inner["x"] >= outer["x"] - EPSILON
            and inner["y"] >= outer["y"] - EPSILON
            and inner["x"] + inner["width"] <= outer["x"] + outer["width"] + EPSILON
            and inner["y"] + inner["height"] <= outer["y"] + outer["height"] + EPSILON)


def load_contract():
    path = REPO / "cloud/task088_stage3_renderer/uaart_market_prices.py"
    spec = importlib.util.spec_from_file_location("price_source_contract", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, path


def expected_amount(contract, value, language):
    canonical = contract.normalized_usd(value)
    if not canonical:
        return canonical, contract.MISSING[language]
    integer, separator, fraction = canonical.partition(".")
    groups = []
    while integer:
        groups.append(integer[-3:])
        integer = integer[:-3]
    return canonical, " ".join(reversed(groups)) + (separator + fraction if separator else "") + " $"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-rows", type=Path, required=True)
    parser.add_argument("--report", type=Path, default=HERE / "RAW_BROWSER_EVIDENCE_VALIDATION.json")
    parser.add_argument("--expect-complete", action="store_true")
    args = parser.parse_args()
    contract, contract_path = load_contract()
    sources = json.loads(args.source_rows.read_text())
    rows = {row["auto_number"]: row for row in sources}
    if len(sources) != 18 or len(rows) != 18:
        raise ValueError("Expected 18 distinct independently captured published car rows")
    if any(row.get("published") not in (1, "1", True) for row in sources):
        raise ValueError("Expected source includes a car that is not marked published")
    expected_paths = {f"/video/{code}.html" for code in rows} | {"/video/index.html", "/video/katalog.html"}
    expected_keys = {(path, lang, width, height) for path in expected_paths for lang in LANGUAGES for width, height in VIEWPORTS}
    config_path = HERE / "harness_config.json"
    config = json.loads(config_path.read_text())
    candidate_hashes = {doc["path"]: doc["sha256"] for doc in config["documents"]}
    historical_path = REPO / "cloud/task088_v5_acceptance/KYIV_PREVIEW_BROWSER_OBSERVATIONS.json"
    observations = [(historical_path, index, observation) for index, observation in enumerate(json.loads(historical_path.read_text()))]
    inputs = [{"path": str(historical_path.relative_to(REPO)), "sha256": digest(historical_path)}]
    input_errors = []
    for path in sorted(HERE.glob("raw_*.json")):
        try:
            observation = json.loads(path.read_text())
            if not isinstance(observation, dict):
                raise ValueError("Raw observation is not an object")
            observations.append((path, None, observation))
            inputs.append({"path": str(path.relative_to(REPO)), "sha256": digest(path)})
        except (ValueError, OSError) as error:
            input_errors.append({"path": str(path.relative_to(REPO)), "error": str(error)})

    results = []
    all_keys = []
    for source, index, observation in observations:
        failures = []
        checks = 0

        def check(condition, label):
            nonlocal checks
            checks += 1
            if not condition:
                failures.append(label)

        key = key_of(observation)
        all_keys.append(key)
        path, requested_language, width, height = key
        language = LANGUAGES.get(requested_language)
        check(key in expected_keys, "expected_page_language_viewport")
        check(observation.get("candidate_sha256") == candidate_hashes.get(path) and bool(candidate_hashes.get(path)), "candidate_sha256_matches_current_harness")
        check(observation.get("status") == "OBSERVED_ONLY" and observation.get("acceptance") == "NOT_EVALUATED", "raw_observation_preserved")
        check(bool(observation.get("observed_at")), "observation_timestamp_present")
        check(observation.get("language") == language and language is not None, "rendered_language_matches_requested_language")
        check(observation.get("actual_css_viewport") == {"width": width, "height": height}, "actual_viewport_matches_requested_dimensions")
        check(observation.get("exact_dimensions") is True and observation.get("viewport_media_match") is True, "viewport_exact_and_media_query_match")
        check(observation.get("ready_state") == "complete", "document_complete")
        check(observation.get("fonts_status") == "loaded", "fonts_loaded")
        document_width = observation.get("document_width")
        scroll_width = observation.get("document_scroll_width")
        width_valid = numeric(document_width) and numeric(scroll_width) and numeric(width) and 0 < document_width <= width
        check(width_valid and scroll_width <= document_width + EPSILON, "document_has_no_horizontal_overflow")
        groups = observation.get("prices", [])
        expected_codes = sorted(rows) if path == "/video/katalog.html" else ([] if path == "/video/index.html" else [Path(path or "").stem])
        check(sorted(group.get("car", "") for group in groups) == expected_codes, "exact_expected_car_price_group_coverage")
        compact = path == "/video/katalog.html"
        for group in groups:
            code = group.get("car")
            row = rows.get(code)
            if not row or not language or not width_valid:
                check(False, f"{code}:required_source_context")
                continue
            group_box = group.get("box")
            group_valid = usable_box(group_box, document_width)
            check(group_valid, f"{code}:price_group_nonzero_and_fits_document")
            status = str(row.get("status") or "").strip().lower()
            kyiv = status.startswith("ua_") or status in ("sold", "archive")
            expected_markets = ["ukraine"] if kyiv else ["ukraine", "georgia"]
            market_rows = group.get("rows", [])
            check([market.get("market") for market in market_rows] == expected_markets, f"{code}:market_order_and_kyiv_ua_only")
            previous_box = None
            for market_row in market_rows:
                market = market_row.get("market")
                if market not in ("ukraine", "georgia"):
                    check(False, f"{code}:known_market")
                    continue
                field = "price_uah" if market == "ukraine" else "price_georgia"
                canonical, amount_text = expected_amount(contract, row.get(field), language)
                country = contract.COUNTRIES[market][language]
                heading = f"{contract.FLAGS[market]} {country} — {amount_text}"
                expected_text = heading + ("" if compact else " " + contract.CAPTIONS[market][language])
                check(market_row.get("value") == canonical, f"{code}:{market}:exact_independent_source_value")
                check(normalized_text(market_row.get("text")) == normalized_text(expected_text), f"{code}:{market}:exact_translated_country_amount_caption")
                box = market_row.get("box")
                box_valid = usable_box(box, document_width)
                check(box_valid, f"{code}:{market}:row_nonzero_and_fits_document")
                if box_valid and group_valid:
                    check(inside(box, group_box), f"{code}:{market}:row_inside_price_group")
                if previous_box and box_valid:
                    check(box["y"] >= previous_box["y"] + previous_box["height"] - EPSILON, f"{code}:{market}:market_rows_do_not_overlap")
                previous_box = box if box_valid else None
                text_sizes = market_row.get("text_sizes", [])
                expected_text_parts = [heading, country, amount_text] + ([] if compact else [contract.CAPTIONS[market][language]])
                check([normalized_text(item.get("text")) for item in text_sizes] == [normalized_text(item) for item in expected_text_parts], f"{code}:{market}:expected_measured_text_elements")
                expected_font_sizes = [16 if compact else 25] * 3 + ([] if compact else [14])
                check([item.get("font_size") for item in text_sizes] == [f"{size}px" for size in expected_font_sizes], f"{code}:{market}:source_contract_font_sizes")
                for position, text_item in enumerate(text_sizes):
                    text_box = text_item.get("box")
                    text_valid = usable_box(text_box, document_width)
                    check(text_valid, f"{code}:{market}:text_{position}_nonzero_and_fits_document")
                    if text_valid and box_valid:
                        check(inside(text_box, box), f"{code}:{market}:text_{position}_inside_row")
        results.append({"case": compact_key(key), "status": "PASS" if not failures else "FAIL", "checks": checks,
                        "observed_at": observation.get("observed_at"), "candidate_sha256": observation.get("candidate_sha256"),
                        "source": str(source.relative_to(REPO)), "source_array_index": index, "failures": failures})

    counts = Counter(all_keys)
    unique_keys = set(all_keys)
    missing = sorted(compact_key(key) for key in expected_keys - unique_keys)
    unexpected = sorted(compact_key(key) for key in unique_keys - expected_keys)
    duplicates = {compact_key(key): count for key, count in counts.items() if count > 1}
    failed = [result for result in results if result["status"] != "PASS"]
    status = "FAIL" if failed or unexpected or duplicates or input_errors else ("PARTIAL" if missing else "PASS")
    report = {
        "scope": "Saved browser CSS observation matrix only; not full Preview Gate, Stage 4, production publication, or Safari/iOS acceptance",
        "status": status,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "expected_unique_cases": len(expected_keys), "observed_unique_cases": len(unique_keys),
        "observed_records": len(observations), "passed_records": len(results) - len(failed), "failed_records": len(failed),
        "total_assertions": sum(result["checks"] for result in results),
        "historical_records_reused": sum(index is not None for _, index, _ in observations),
        "new_records": sum(index is None for _, index, _ in observations),
        "pages": len(expected_paths), "languages": LANGUAGES,
        "viewports_css": [{"width": width, "height": height} for width, height in VIEWPORTS],
        "missing_cases": missing, "unexpected_cases": unexpected, "duplicate_cases": duplicates, "input_errors": input_errors,
        "current_harness_config_sha256": digest(config_path), "renderer_contract_sha256": digest(contract_path),
        "expected_published_row_source_sha256": digest(args.source_rows), "expected_published_row_count": len(sources),
        "kyiv_car_codes": sorted(code for code, row in rows.items() if str(row.get("status") or "").strip().lower().startswith("ua_") or str(row.get("status") or "").strip().lower() in ("sold", "archive")),
        "raw_inputs": inputs, "cases": sorted(results, key=lambda result: result["case"]),
        "limitations": [
            "Candidate hashes are browser harness observation fields matched against saved current configuration; live server freshness is an independent check.",
            "Historical source rows are checked by digest and exact per-market values; live CRM source freshness is an independent check.",
            "Nonzero in-document boxes establish measured layout, including rows below the initial viewport; this does not establish opacity, occlusion, screenshot appearance, or actual user interaction.",
            "Lazy images may not all decode before measurement. This report does not claim all images, links, navigation, or native actions were checked.",
            "CSS viewport observations use the available browser and are not mobile OS, Safari, touch, or network-provider emulation.",
            "Screenshots and top-level link checks remain separate evidence. No complete publication gate verdict is issued here.",
        ],
    }
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "expected_unique_cases", "observed_unique_cases", "passed_records", "failed_records", "total_assertions", "historical_records_reused", "new_records")}, ensure_ascii=False))
    if failed:
        print(json.dumps([{"case": result["case"], "failures": result["failures"]} for result in failed], ensure_ascii=False, indent=2))
    return 1 if status == "FAIL" or (args.expect_complete and status != "PASS") else 0


if __name__ == "__main__":
    raise SystemExit(main())
