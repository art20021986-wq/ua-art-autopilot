# PR 114: strict workflow test reconciliation

The requested test repair is complete. Only these implementation-tracked test
files changed; runtime code, workflows, policy constants, activation records,
real manifests and Production were not changed by this workstream:

- `automation/packages/task107_r2/test_workflow_contracts.py`
- `automation/packages/task107_r2/test_task088_storage_override.py`

## Results

| Verification | Final result |
| --- | --- |
| Workflow-contract suite | 37/37 PASS, 0 failures/errors/skips |
| Required maintenance unittest discovery | 183/183 PASS, 0 failures/errors/skips |
| Maintenance compilation prerequisite | PASS for all 7 permanent modules |
| Maintenance module self-tests | All 3 PASS |
| Previously verified price source closure | Unchanged; historical 443 checks remain bound to the same source |
| Independent read-only review | No blocking findings for either test change |

The workflow suite's 37 tests are included in the 183 maintenance tests. Do not
add those duplicate counts. The unchanged 443 price checks were not rerun simply
because tests outside their source closure changed. The 82-source manifest is
still `18fc3c2ffb16df204cdd7318f550fbffa0a2169da3be57ff0d2bc88b1855b5c7`.

This is a local execution of the required test commands. It is not a successful
GitHub Actions maintenance run, live `verify-mode`, runtime activation, full
Preview, Gate B or Production acceptance. The actual deployment must still
validate its current canonical mode, pins, request and authorization normally.

## Why the workflow tests changed

Two old tests still expected merge-tolerant autostart even though the pinned
workflow intentionally restored direct-parent-only behavior in commit
`213adac29d204be47da4cd39bff0c81a7605e6ae`. The repaired test executes all three
actual shell guards with mocked git output: one exact parent succeeds, ordinary
merges, reversed parents, octopus merges, wrong source, missing parent and empty
output fail. A separately implemented acceptance predicate was removed.

Five old tests predated the registered recovery routes. The repair retains the
exact six legacy watchdog writer identities, six-attempt retries and previously
required accepted-path drift checks. Exactly the two existing recovery writer
identities receive separate assertions for one push, fixed parent, exact lease,
exact changed-path count and names, and path/runtime readback after the push.
No generic exemption for other writers was introduced.

The three existing recovery queue steps are identified by workflow, job and
step. Their actual loops execute with only `gh` mocked; expanded argv must be
GET requests to the precise repository Actions endpoint, with pagination, for
all five pending/active statuses. Their token scope remains restricted and no
repository Python is allowed in those token-bearing queue steps.

New negative tests call the actual unchanged control-plane verifiers with
mutated workflow text. They require rejection of premature repository Python,
POST requests, wrong repository identity, missing lease/path/readback guards,
canary changes to HALT, missing owner/plan bindings, and scheduled execution.
Endpoint drift is honestly tested through the existing exact workflow pin.
No pin or verifier is monkeypatched and no failure is skipped or expected-away.

## Why the storage fixture changed

Full maintenance discovery then exposed two additional errors in the old
CRM-only storage-waiver fixture. It copied the current maintenance workflow
containing the later price gate while retaining the older independently pinned
manifest hash. The earlier waiver cannot authorize that newer workflow.

The fixture now reconstructs only the exact historical maintenance bytes in
its `TemporaryDirectory`: it removes one explicitly known added test step and
requires the result to match the existing previous-manifest SHA
`9de321b12e06173a773a07af5954ff27b467b492a247ca7a04751dab776f24fb` before writing.
Any unrelated drift causes a test failure. It does not rewrite or relax any
real hash. A new negative test calls complete `verify_execution_mode` after
altering the temporary maintenance file and requires the precise pinned-file
hash mismatch. The real maintenance workflow retains its price gate.

## Reproducibility and preserved development evidence

The final maintenance command is the workflow's required discovery command,
with `-B` added solely to prevent bytecode creation in the source checkout:

```sh
python3 -I -B -m unittest discover -s automation/packages/task107_r2 -p 'test_*.py' -v
```

The same `py_compile` compiler ran with warnings treated as errors; generated
bytecode was directed to disposable temporary paths. All three named module
self-tests ran without inherited application credentials. Shell probes used
synthetic values and made no network calls.

- `test_only_fix.patch`: exact reviewable changes to the two test files.
- `test_fix_binding.json`: final test hashes, patch hash and unchanged source closure.
- `workflow_after_final.json` and associated raw logs: 37 PASS.
- `maintenance_discovery_final.json` and associated raw logs: 183 PASS.
- `maintenance_prerequisites.json` and self-test logs: compile/self-test PASS.
- `workflow_after.json`: initial development run; four failures in new mutation
  probes were corrected (three missing `/usr/bin/` anchors and one mutation of
  only one repeated identity marker). The original seven assertions had already
  passed in that run. These raw development results were retained.
- `maintenance_discovery.json`: initial 182-test run exposing the two historical
  fixture mismatches. It is superseded by the complete 183-test PASS after the
  isolated fixture repair and added negative test.

No commits, pushes, credentials, live-server calls or Production writes were
performed by this test-repair workstream. The root agent reviews and persists
the patch through the authorized PR workflow.
