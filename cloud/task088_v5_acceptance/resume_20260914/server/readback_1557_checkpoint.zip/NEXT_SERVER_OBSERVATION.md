# Next install observation, after current Preview repair

The 15:57 freshness readback cannot replace the install observer: it lacks the complete media/root-source inventory with modes and sizes, stage counts, and the install engine database representation. No conversion of that receipt into an install PASS is valid.

A one-file read-only delivery is prepared: `observe_install_inputs_20260914.pyz` (see exact hash and payload closure in `observe_install_kit_manifest.json`). It embeds byte-identical reviewed observer and install engine code. It compiles pinned payload bytes in memory, extracts no files, rejects hidden inventory paths, and imports no live source. Its only output is JSON on stdout. The existing observer's PASS means complete input observation, never full Preview or production Gate.

Upload this one archive to a new private task path and verify its SHA256. Run `python3.10 -I -B /home/Carix/autopilot_inbox/cloud/observe_install_inputs_20260914.pyz`, preserving stdout with no-clobber mode0600 in a unique private output. The embedded account quota from15:43:25Z expires at16:13:25Z; after that supply an independently refreshed authenticated quota JSON using `--quota-json ABSOLUTE_PATH`. Never edit its timestamp to make it current. At observation it showed30,085,906,432bytes remaining; backup requirements still need actual full inventory sizing.

After a real observation, verify its server SHA256 and preserve exact bytes locally. Within30minutes, use the existing build_preflight_bundle.py with that observation, canonical Stage2receipt state/receipts/TASK088-GE-PRICE-CRM-STAGE2.json, and routing evidence cloud/task088_v5_acceptance/route_observations.json. The routing pins have been checked against fresh15:57inventory; the old base-response observation remains historical.

A preflight package must then be staged to a unique private task088_price_sync_* directory, archive/member hashes verified, and preflight.py run with its exact bundle hash. Its private candidate work and SQLite copies require fresh quota and disk checks; source and public files are not written. Its expected overall BLOCKED status for missing canonical control evidence must not be converted to PASS.

Priority is now the independently identified Preview gallery manifest repair. No request to a browser-policy-blocked image URL, alternate image exposure, or production change is part of this plan.
