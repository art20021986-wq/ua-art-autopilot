"""One-file delivery of the existing pinned read-only install observer.

Executed from its reviewed .pyz with python3.10 -I -B. Payloads are compiled
directly from pinned archive bytes: no extraction, backup, import of live
modules, production action, credential use, or Gate creation.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import types
import zipfile

PINS = {
    'observe_install_inputs.py': '626bb2142367b1b1d251fc131ee6365d6285fea6daa0cd08d2b8bc565d56a42f',
    'install_package.py': '3d74fc2a71160af18cb8dc705fbaa76ca367a348a6c984f59a4b4768e6fac673',
}


def load(name, raw):
    if hashlib.sha256(raw).hexdigest() != PINS[name]:
        raise ValueError('PINNED_OBSERVER_PAYLOAD_REQUIRED')
    module = types.ModuleType('reviewed_' + name[:-3])
    module.__file__ = str(Path(sys.argv[0]).absolute()) + '/' + name
    sys.modules[module.__name__] = module
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
    return module


def reject_hidden_inventory_paths():
    root = Path('/home/Carix')
    for pattern in ('*.py', '*.html', '*.css', '*.js'):
        if any(path.name.startswith('.') for path in root.glob(pattern)):
            raise ValueError('HIDDEN_SOURCE_REQUIRES_REVIEW')
    for folder in ('video', 'site'):
        base = root / folder
        if base.resolve(strict=True) != base or not base.is_dir():
            raise ValueError('EXACT_PUBLIC_ROOT_REQUIRED')
        for directory, dirs, files in os.walk(base, followlinks=False):
            if any(name.startswith('.') for name in dirs + files):
                raise ValueError('HIDDEN_PUBLIC_ENTRY_REQUIRES_REVIEW')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--quota-json', help='Optional new authenticated quota file; embedded evidence expires after 1800 seconds.')
    args = parser.parse_args()
    try:
        if not sys.flags.isolated or not sys.dont_write_bytecode:
            raise ValueError('PYTHON_ISOLATED_NO_BYTECODE_REQUIRED')
        archive = Path(sys.argv[0]).absolute()
        if archive.resolve(strict=True) != archive or not archive.is_file():
            raise ValueError('EXACT_REVIEWED_ARCHIVE_REQUIRED')
        with zipfile.ZipFile(archive) as packed:
            if sorted(packed.namelist()) != sorted((*PINS, '__main__.py', 'quota_observation.json')):
                raise ValueError('EXACT_OBSERVER_ARCHIVE_MEMBERS_REQUIRED')
            engine = load('install_package.py', packed.read('install_package.py'))
            observer = load('observe_install_inputs.py', packed.read('observe_install_inputs.py'))
            quota_raw = packed.read('quota_observation.json')
        if args.quota_json:
            path = Path(args.quota_json).absolute()
            if path.resolve(strict=True) != path or not stat.S_ISREG(path.stat().st_mode) or path.stat().st_size > 8192:
                raise ValueError('EXACT_BOUNDED_QUOTA_FILE_REQUIRED')
            quota_raw = path.read_bytes()
        quota = json.loads(quota_raw)
        # Reject stale quota before potentially lengthy complete-tree hashing.
        from datetime import datetime, timezone
        engine._fresh(quota.get('observed_at'), datetime.now(timezone.utc).timestamp())
        reject_hidden_inventory_paths()
        report = observer.observe(engine, quota)
        report['observation_scope'] = 'READ_ONLY_INSTALL_INPUTS_ONLY_NOT_FULL_PREVIEW_OR_GATE'
        report['observer_payload_sha256'] = PINS
        report['full_preview'] = 'NOT_PASSED'
        report['production_gate'] = 'NOT_CREATED'
        print(json.dumps(report, ensure_ascii=True, sort_keys=True, separators=(',', ':')))
        return 0
    except Exception as error:
        message = str(error)
        print(json.dumps({'status': 'OBSERVATION_INCOMPLETE', 'read_only': True,
            'error_type': type(error).__name__,
            'code': message if re.fullmatch('[A-Z0-9_]{1,120}', message) else 'REDACTED_ERROR_MESSAGE',
            'full_preview': 'NOT_PASSED', 'production_gate': 'NOT_CREATED',
            'live_files_written': False, 'crm_written': False}, sort_keys=True))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
