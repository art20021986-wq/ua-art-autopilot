# Prior watchdog canary failure: cause and gate impact

Investigation only. No watchdog code, workflows, pins, live state, recovery jobs
or Production were changed or rerun. The existing failure is preserved.

## Authentic observations

GitHub connector reads verified run `34847065870` on main commit
`0c85a6561d80c4d8789b3a482ae41cdaf9d0f667`. At 13:05 UTC on 14 September:

- `discover`, job `103985492478`: success, `transaction_status: NONE`.
- `recovery_canary`, job `103985556482`: runtime bootstrap and GET-only queue
  capture passed; data-only proposal validation failed with
  `RECOVERY_CANARY_RECEIPT_BINDING`.
- Canary persistence and result verification were skipped. This failure did
  not reach its Git write step.
- The current main HALT file returned connector 404. Exact main Git data also
  contains no HALT and no pending transaction.

Raw job logs, complete job summaries, connector read provenance and relevant
current main records are retained in this directory. Current PR metadata at
observation was head `c76c4c5d09efcb11a43c37aee9b56d2c86995112`, open/draft,
unmerged, with the same main base.

## Reproduced cause

The receipt was added once in immutable commit
`1bfac9fe6293dd3060def06a23777c7ddb1f84d9`, parent
`e76daffc9c50fb0a44da019ae2989d0b4578bc27`, on 9 September. Its bytes remain
unchanged. Its runtime manifest SHA is
`a287f583bf5b7e1df8d3d562d7c99afc540e6c74cea7a9c0c0b4d276da6b945c`.

The later authorized TASK088 storage activation changed exactly
`automation/control_plane.py` and `uaart_critical.yml`. Current main's manifest
SHA is `2b3b75c686a41f4f6a48b2f9e2d57da12574c2b498505150899b66645d7cd2c5`.
The old manifest remains the independently pinned predecessor in that current
authorization chain.

`_rcanary` compares the historical receipt's runtime hashes and manifest to the
current runtime, including in the existing-receipt NOOP path. Those two
comparisons fail after the authorized runtime update. Every other receipt
identity predicate passes.

The actual unmodified main watchdog was loaded from an exact temporary main
snapshot. Its strict `_rcanary` validator passed against the receipt's immutable
origin and reproduced `RECOVERY_CANARY_RECEIPT_BINDING` against current main.
The same exact main snapshot passed full `verify_execution_mode(AUTOMATIC)` and
`assert_clear` with zero pending transactions. This is offline commit-bound
verification, not a new live Actions execution.

## Approved specification section 5: exact impact

This failure is a separate recovery NOOP defect, not a direct forward-install
prerequisite in the reviewed main/candidate code:

- CRITICAL calls `verify-mode`, `assert-clear` and `discover`; none validates
  the old canary receipt.
- `_rcanary` is called only by recovery-canary, recovery-execute and
  recovery-verify. CRITICAL has no dependency on `recovery_canary`.
- A completed failed run does not occupy the active-run production queue.

This classification does not remove or relabel a required check. GitHub branch
protection/required status policy was not exposed by the available read tools
and is not asserted here. If this check is externally required, that condition
still blocks release. Full Preview, fresh current state, exact canonical
activation, writer exclusion, backup and post-deploy gates remain mandatory.
Healthy watchdog or full Stage 4 PASS must not be inferred from this report.

## Minimal possible repair, for separate source review

No repair was applied. The smallest safe design is to distinguish immutable
historical NOOP proof from current execution authorization:

1. Preserve the existing current-runtime `verify_execution_mode` before NOOP.
2. Only for an already existing recovery-canary NOOP, locate the single immutable
   receipt addition, prove its ancestor relation/current identical receipt
   bytes, and validate its historical snapshot using the existing strict
   `_rcanary` checks for identity, single-add scope, parent, HALT and hashes.
3. Bind that historical runtime to the independently verified current
   activation predecessor chain; report explicit historical provenance,
   `ready: false`, no changes and zero application writes.
4. Retain strict current-runtime matching for recovery-execute and fresh
   recovery-verify. Historical proof must never authorize a write.
5. Preserve the old receipt unchanged. Never delete, replace or refresh it
   merely to silence the error.

Required regression cases: authorized CP/critical evolution permits historical
NOOP; changed receipt/history/parent/HALT/origin hashes, unapproved current mode,
missing lineage or non-ancestor origin reject; execute with stale runtime still
rejects; no result ever requests an additional receipt or state write.

`transaction_watchdog.py` is a pinned runtime file outside the current Stage 3
`PRICE_V5_RUNTIME_PATHS`. Any implementation therefore requires its own reviewed
authorized runtime activation, not widening the old Stage 3 manifest or
rewriting pins to make tests green.

## Evidence

`BINDING_REPRODUCTION.json` contains the exact source hash, immutable history,
both runtime bindings, the two mismatched paths, actual strict validator
results and offline mode/assert-clear results. `reproduce_binding.py` performs
read-only Git object reads and temporary extraction; it invokes no recovery
proposal, writer or workflow launch. Connector and local Git bytes for the
receipt, manifest and execution mode were compared exactly.
