#!/usr/bin/env python3
"""Read-only historical canary diagnosis against an exact main Git tree."""
import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent
MAIN = '0c85a6561d80c4d8789b3a482ae41cdaf9d0f667'
ADDITION = '1bfac9fe6293dd3060def06a23777c7ddb1f84d9'
CANARY = 'state/recovery_route_receipts/UA-ART-RECOVERY-TASK120-002.json'
MANIFEST = 'state/AUTOPILOT_RUNTIME_MANIFEST.json'

def git(*args):
    return subprocess.check_output(['/usr/bin/git', '--no-replace-objects', *args], cwd=ROOT)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    report = {'scope':'OFFLINE_EXACT_MAIN_TREE_DIAGNOSIS_NOT_LIVE_JOB_OR_AUTHORIZATION',
              'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'main_commit':MAIN,'canary_addition_commit':ADDITION,'mutations':[]}
    with tempfile.TemporaryDirectory(prefix='pr114-main-canary-readonly-') as temporary:
        snapshot = Path(temporary)
        raw = git('archive', '--format=tar', MAIN)
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            archive.extractall(snapshot, filter='data')
        spec = importlib.util.spec_from_file_location('exact_main_watchdog', snapshot/'automation/transaction_watchdog.py')
        watchdog = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = watchdog
        spec.loader.exec_module(watchdog)
        cp = watchdog.cp
        mode = cp.verify_execution_mode(root=snapshot, required_mode='AUTOMATIC')
        clear = watchdog.assert_clear(root=snapshot)
        report['offline_current_main_mode'] = {key:mode[key] for key in ('status','mode','mode_epoch','runtime_activation_path','runtime_manifest_sha256')}
        report['offline_current_main_assert_clear'] = clear
        paths = set(cp.RUNTIME_PINNED_PATHS) | {CANARY,MANIFEST}
        current = {path:git('show', MAIN+':'+path) for path in paths}
        historical = {path:git('show', ADDITION+':'+path) for path in paths}
        for remote_name, path in [('main_canary_receipt.json',CANARY),('main_runtime_manifest.json',MANIFEST),('main_execution_mode.json','state/EXECUTION_MODE.json')]:
            if (OUT/remote_name).read_bytes() != git('show', MAIN+':'+path):
                raise ValueError('CONNECTOR_LOCAL_GIT_BYTES_MISMATCH:'+path)
        report['connector_local_git_bytes_match'] = True
        report['current_watchdog_sha256'] = sha(current['automation/transaction_watchdog.py'])
        report['local_candidate_watchdog_matches_main'] = (ROOT/'automation/transaction_watchdog.py').read_bytes()==current['automation/transaction_watchdog.py']
        report['historical_canary_verification'] = watchdog._rcanary(ROOT,historical,ADDITION)
        try:
            watchdog._rcanary(ROOT,current,MAIN)
        except watchdog.WatchdogError as error:
            report['current_canary_result'] = {'status':'FAIL','reason':str(error)}
            if str(error) != 'RECOVERY_CANARY_RECEIPT_BINDING':
                raise
        else:
            raise AssertionError('EXPECTED_CURRENT_BINDING_FAILURE_NOT_REPRODUCED')
        receipt = json.loads(current[CANARY])
        runtime = json.loads(current[MANIFEST])
        report['runtime_changed_paths'] = [
            {'path':path,'receipt_sha256':receipt['runtime_hashes'].get(path),'current_sha256':sha(current[path])}
            for path in cp.RUNTIME_PINNED_PATHS if receipt['runtime_hashes'].get(path) != sha(current[path])]
        report['runtime_manifest_binding'] = {'receipt_sha256':receipt['runtime_manifest_sha256'],
            'historical_actual_sha256':sha(historical[MANIFEST]),'current_actual_sha256':sha(current[MANIFEST])}
        report['receipt_unchanged_since_origin'] = current[CANARY] == historical[CANARY]
        report['single_immutable_receipt_history'] = git('log','--format=%H','--full-history',MAIN,'--',CANARY).decode().splitlines()
        report['addition_parent'] = git('show','-s','--format=%P',ADDITION).decode().strip()
        report['addition_changes'] = git('diff-tree','--no-commit-id','--name-status','-r',receipt['parent_commit'],ADDITION).decode().splitlines()
        report['main_halt_present'] = (snapshot/'state/AUTOPILOT_HALT.json').exists()
        report['historical_runtime_is_current_authorized_predecessor'] = (
            receipt['runtime_manifest_sha256'] == cp.TASK088_PREVIOUS_MANIFEST_SHA256
            and sha((snapshot/cp.TASK088_PREVIOUS_MANIFEST_PATH).read_bytes()) == receipt['runtime_manifest_sha256'])
        report['historical_receipt_identity_checks'] = {
            'schema':receipt.get('schema_version')=='UA-ART-RECOVERY-ROUTE-CANARY-1',
            'task':receipt.get('task_id')==watchdog.RECOVERY_TASK,
            'repository':receipt.get('repository')==watchdog.RECOVERY_REPOSITORY,
            'halt_sha':receipt.get('halt_sha256')==watchdog.RECOVERY_HALT_SHA,
            'reconciliation_sha':receipt.get('reconciliation_sha256')==watchdog.RECOVERY_RECON_SHA,
            'halt_removed_false':receipt.get('halt_removed') is False,
            'application_writes_zero':receipt.get('application_writes')==0,
        }
        report['forward_production_gate_impact'] = {
            'assert_clear_uses_historical_canary':False,
            'current_mode_validation_uses_canary_receipt':False,
            'historical_failed_run_holds_active_queue':False,
            'github_required_checks_or_branch_protection_verified':False,
            'conclusion':'SEPARATE_RECOVERY_NOOP_DEFECT; NOT_A_DIRECT_FORWARD_INSTALL_PREREQUISITE_IN_REVIEWED_CODE',
            'does_not_grant_production_or_healthy_stage4_pass':True,
        }
    with (OUT/'BINDING_REPRODUCTION.json').open('x') as stream:
        json.dump(report,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(report,indent=2,sort_keys=True))

if __name__=='__main__':
    main()
