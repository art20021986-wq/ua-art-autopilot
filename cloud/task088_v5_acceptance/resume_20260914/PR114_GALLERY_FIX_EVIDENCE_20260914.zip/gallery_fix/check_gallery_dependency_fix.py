"""Software-only reproduction of the observed missing full-size gallery asset.

Uses the existing private capture read-only, with isolated synthetic media files.
Does not contact any server, write Production, or grant browser/Preview PASS.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types

sys.dont_write_bytecode = True
BASELINE = 'e146c2ea8c28033050b49ccbebb33aa5276c8788'
BUILDER_PATH = 'cloud/task088_v5_preview/build_preview.py'
BUILDER_SHA256 = '0137d0077ef485679feea238b579b629f8c281542ca28a7277b769d5a7b8fa02'


def verify(repo, snapshot):
    preview = repo / 'cloud/task088_v5_preview'
    sys.path.insert(0, str(preview))
    import build_preview as fixed
    from common import encoded, sha
    from wsgi_preview import Preview
    assert sha((repo / BUILDER_PATH).read_bytes()) == BUILDER_SHA256
    old = types.ModuleType('gallery_baseline')
    old.__file__ = str(repo / BUILDER_PATH)
    old_raw = subprocess.check_output(['git', 'show', BASELINE + ':' + BUILDER_PATH], cwd=repo)
    exec(compile(old_raw, old.__file__, 'exec'), old.__dict__)
    routing = repo / 'cloud/task088_v5_acceptance/route_observations.json'
    added = {}
    for card in sorted((snapshot / 'video').glob('UA-????.html')):
        source = card.read_text()
        added[card.name] = len(fixed.References(source).references - old.References(source).references)
    assert len(added) == 18 and added['UA-0015.html'] == 37
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        public = root / 'assets'
        photos = public / 'foto/UA-0015'
        photos.mkdir(parents=True)
        good = b'ISOLATED_FULLSIZE_MEDIA_FIXTURE'
        (photos / '002.jpg').write_bytes(good)
        (photos / '099.jpg').write_bytes(b'UNLISTED_PRIVATE_BOUNDARY_FIXTURE')
        outside = root / 'outside.jpg'
        outside.write_bytes(b'SYMLINK_TARGET_MUST_NOT_BE_SERVED')
        (photos / '003.jpg').symlink_to(outside)
        before = old.build(snapshot, root / 'before', 'https://www.uaart.com.ua', routing, public)
        after = fixed.build(snapshot, root / 'after', 'https://www.uaart.com.ua', routing, public)
        oldmanifest = json.loads((root / 'before/manifest.json').read_text())
        manifest = json.loads((root / 'after/manifest.json').read_text())
        oldfiles = {str(p.relative_to(root / 'before')): sha(p.read_bytes())
                    for p in (root / 'before').rglob('*.html')}
        newfiles = {str(p.relative_to(root / 'after')): sha(p.read_bytes())
                    for p in (root / 'after').rglob('*.html')}
        assert oldfiles == newfiles
        assert all(manifest['files'][route] == item for route, item in oldmanifest['files'].items())
        newroutes = sorted(set(manifest['files']) - set(oldmanifest['files']))
        assert newroutes == ['/video/foto/UA-0015/002.jpg']
        for filename in ('099.jpg', '003.jpg'):
            assert '/video/foto/UA-0015/' + filename not in manifest['files']
        item = manifest['files'][newroutes[0]]
        assert item['sha256'] == sha(good) and item['bytes'] == len(good) and item['content_type'] == 'image/jpeg'
        assert item['storage'] == 'asset' and item['path'] == 'foto/UA-0015/002.jpg'
        provenance = json.loads((root / 'after/provenance.json').read_text())
        assert {'path': '/video/foto/UA-0015/003.jpg', 'reason': 'ASSET_MISSING_UNREADABLE_OR_UNBOUNDED'} in provenance['missing_assets']
        config = root / 'config.json'
        config.write_bytes(encoded({'contract': manifest['contract'], 'preview_origin': 'https://preview.example',
            'bundle_root': str(root / 'after'), 'manifest_sha256': after['manifest_sha256'],
            'access_policy': 'PUBLIC_READ_ONLY_PREVIEW_OWNER_AUTHORIZED'}))
        config.chmod(0o600)
        app = Preview(config)

        def call(route):
            result = {}
            def start(status, headers):
                result.update(status=status)
            result['body'] = b''.join(app({'wsgi.url_scheme': 'https', 'HTTP_HOST': 'preview.example',
                'REQUEST_METHOD': 'GET', 'PATH_INFO': route}, start))
            return result

        assert call(newroutes[0]) == {'status': '200 OK', 'body': good}
        for route in ('/video/foto/UA-0015/099.jpg', '/video/foto/UA-0015/003.jpg',
                      '/video/foto/UA-0015/', '/video/foto/UA-0015/../../outside.jpg'):
            assert call(route)['status'] == '404 Not Found'
        (photos / '002.jpg').write_bytes(b'TAMPERED')
        changed = call(newroutes[0])
        assert changed['status'] == '503 Service Unavailable' and b'TAMPERED' not in changed['body']
        return {'status': 'PASS', 'builder_sha256': BUILDER_SHA256,
            'baseline_commit': BASELINE, 'baseline_builder_sha256': sha(old_raw),
            'capture_manifest_sha256': sha((snapshot / 'capture_manifest.json').read_bytes()),
            'captured_cards': len(added), 'newly_discovered_per_card_fullsize_references': sum(added.values()),
            'by_card': added, 'protected_html_and_harness_identical_files': len(oldfiles),
            'protected_html_and_harness_sha256': oldfiles,
            'existing_manifest_entries_unchanged': len(oldmanifest['files']),
            'fixture_new_route': newroutes[0], 'fixture_positive_http': '200 OK',
            'unlisted_directory_traversal_symlink_http': '404 Not Found', 'drift_http': '503 Service Unavailable',
            'missing_assets_before': before['missing_assets'], 'missing_assets_after': after['missing_assets'],
            'production_written': False, 'preview_gate': 'NOT_PASSED',
            'note': 'Fixture byte payload; software integration only, not a real browser image test.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--snapshot', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.repo.resolve(), args.snapshot.resolve()), indent=2, sort_keys=True))
